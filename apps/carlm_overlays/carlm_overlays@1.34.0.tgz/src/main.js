'use strict';
/*
 * carlm_overlays ("eOverlays"): the control panel of the carlm-overlays tool (own ids beside IterioDev's iteriodev-overlays), the QuickSelect strip in the climate
 * bar (iDrive 8): what each of the four shortcuts opens, the shortcuts / seat / wheel buttons on or off, the tap
 * order, the shift lights on the cluster (cars without their own: drawn by cluster-render, lit from the engine speed;
 * an M car shows its own, so the tool hides ours there), and on M cars which M Mode M1 / M2 switch to. Everything is the tool's: this app talks to it over its control
 * socket (JSON lines, CTL) and shows what it says. The tool pushes every change: a slot saved by a hold in the bar,
 * the seats the car has, the car found to be an M car (its M setup reported). The user can override both: each seat /
 * wheel button AUTO / ON / OFF, the M car AUTO / YES / NO. The Align page nudges each seat / wheel button (or all) into
 * place in px: settings.align (tool 0.5.0), with arrow pads for the heated seat, the steering wheel and the rest.
 *   -> { op: 'get' | 'targets' | 'icons' | 'reset' } | { op: 'set', settings } | { op: 'slot', i, target }
 *      | { op: 'icon', i, icon: name | null } (tool 0.6.0: the slot's own icon in the bar, null = its own picture)
 *   <- { state: { settings, slots: [{ kind, title, icon?, app? }], car: { backend, seats, wheel, mcar, setups } } }
 *      | { targets: { bmw: [{ title, state, applet, icon }], apps: [{ id, title, state, offset, pic (PNG base64) }] } }
 *      | { icons: [{ name, title, pic (PNG base64) }] }
 *
 * Screens: drawn by the GPU renderer, designed in the HMI UI builder: apps/hmi-ui-builder/projects/overlays.json
 * (scripts/oap-tools/make_overlays_project.js), exported into this folder (rhmiData/ = one empty RHMI host state per
 * screen, renderer/ = screens.json + the builder's runtime). Start, tile and shutdown: the shared OnlineApp host
 * (oap-shared/online-host.js).
 */
const fs = require('fs');
const net = require('net');
const path = require('path');
const util = require('util');
const { createHost }                   = require('./online-host.js');

const LOG = '[carlm_overlays]';
const STATES = ['shortcuts', 'pick', 'climate', 'shift', 'mmode', 'align', 'icons', 'finder'];   // screens = their RHMI host states
const CTL = process.env.OVERLAYS_CTL || '/run/carlm-overlays/ctl.sock';
const RETRY_MS = 2000;
const MODES = ['road', 'sport', 'track'];

// the linked bundle is javascript/app.js: the package root (next to renderer/) is its parent folder, the app's data
// folder beside that (the Store's)
const SOURCE = typeof __dirname === 'string' ? path.join(__dirname, '..') : `/var/opt/public/oap/oap_${process.getuid()}/source`;
const DATA = path.join(__dirname, '..', '..', 'data');
const LOG_FILE = `${DATA}/overlays.log`;

function log() {
    const line = [new Date().toISOString()].concat([].slice.call(arguments)
        .map((x) => (typeof x === 'string' ? x : util.inspect(x, { depth: 4 }).slice(0, 2000)))).join(' ');
    console.error(LOG, line);
    try { if (fs.statSync(LOG_FILE).size > 256 * 1024) fs.writeFileSync(LOG_FILE, ''); } catch (e) { /* no file yet */ }
    try { fs.appendFileSync(LOG_FILE, `${line}\n`); } catch (e) { /* no data folder */ }
}

// ---- the tool ---------------------------------------------------------------------------------------------
let tool = null;                  // its last state, null = no connection
let targets = null;               // what a slot can open (asked for when the picker shows)
let icons = null;
let finder = null, finderPage = 0;                 // the Finder's last answer from the tool, the page of it shown
const FINDER_ROWS = 16;                 // the icons a slot can wear (tool 0.6.0; asked for once), uploaded as 'i:<name>'
let sock = null;
let sel = 0;                      // the slot picked on the shortcuts page
let busy = false;                 // a connection being made

function connect() {
    if (sock || busy) return;
    busy = true;
    const s = net.connect(CTL);
    let buf = '';
    s.setEncoding('utf8');
    s.on('connect', () => { busy = false; sock = s; log('tool connected'); if (targets === null) send({ op: 'targets' }); if (icons === null) send({ op: 'icons' }); });
    s.on('data', (d) => {
        buf += d;
        for (let n; (n = buf.indexOf('\n')) >= 0; buf = buf.slice(n + 1)) {
            let m;
            try { m = JSON.parse(buf.slice(0, n)); } catch (e) { continue; }
            if (m.state) tool = m.state;
            if (m.targets) { targets = m.targets; pictures(); }
            if (m.icons) { icons = m.icons; iconPictures(); }
            if (m.finder) { finder = m.finder; if (m.finder.lines) finderPage = 0; }
            render();
        }
    });
    s.on('error', (e) => { if (!/ENOENT|ECONNREFUSED/.test(e.code)) log('tool:', e.message); });
    s.on('close', () => { busy = false; sock = null; tool = null; render(); setTimeout(connect, RETRY_MS); });
}
const send = (q) => { if (sock) sock.write(`${JSON.stringify(q)}\n`); };
const setting = (s) => send({ op: 'set', settings: s });

// ---- screens (the renderer) ----------------------------------------------------------------------------
// renderer/ is the builder's export: screens.json + its runtime. Loaded with a computed path: the linked app.js
// leaves it to the platform require (plain files in the package, Node 8).
const RENDERER = path.join(SOURCE, 'renderer');
const runtime = (f) => require(path.join(RENDERER, f));
let screens = null;
const pics = {};                  // app id -> { len, img }: its picture, uploaded as 'p:<id>'

function pictures() {
    const { makeImage, dropImage } = runtime('kit/record.js'), png = runtime('kit/png.js');
    (targets.apps || []).forEach((a) => {
        if (!a.pic || (pics[a.id] && pics[a.id].len === a.pic.length)) return;
        try {
            const p = png.decode(Buffer.from(a.pic, 'base64')), img = makeImage(p.w, p.h, p.data);
            if (pics[a.id]) dropImage(pics[a.id].img);
            pics[a.id] = { len: a.pic.length, img };
            screens.setImage(`p:${a.id}`, img);
        } catch (e) { log(`picture of ${a.id}:`, e.message); }
    });
}

function iconPictures() {
    const { makeImage } = runtime('kit/record.js'), png = runtime('kit/png.js');
    (icons || []).forEach((ic) => {
        if (!ic.pic) return;
        try { const p = png.decode(Buffer.from(ic.pic, 'base64')); screens.setImage(`i:${ic.name}`, makeImage(p.w, p.h, p.data)); } catch (e) { log(`icon ${ic.name}:`, e.message); }
    });
}
// "Android Auto live" (tool 0.9.0): what the tool reads now, so it can be checked in the car
const aaLine = (a) => (!a ? 'Colour while Android Auto is connected, else white'
    : a.connected ? `Colour while connected · now: connected (${a.via === 'usb' ? 'cable' : 'wireless'})`
        : `Colour while connected · now: not connected${a.pid ? '' : ' (Android Auto service not seen)'}`);
const iconTitle = (name) => { const ic = (icons || []).find((x) => x.name === name); return ic ? ic.title : name; };

/* the cluster's bars (the tool's shiftlights.js shader, on the CPU) with 5 of 8 lit: the shift page's picture of them,
 * the band they sit in (702 x 68 of its 702 x 213) */
function barsPicture() {
    const W = 702, H = 68, d = Buffer.alloc(W * H * 4);
    for (let y = 0; y < H; y++) {
        for (let x = 0; x < W; x++) {
            const px = x + 0.5, py = y + 64.5, xx = px < W / 2 ? px : W - px;
            const xs = xx - 20 - (132 - py) * 0.35, i = Math.floor(xs / 38);
            if (xs < 0 || i > 7 || xs % 38 > 30) continue;
            const c = i >= 5 ? [140, 145, 155, 56] : i < 3 ? [255, 184, 0, 255] : [255, 107, 0, 255];
            d.set(c, (y * W + x) * 4);
        }
    }
    return runtime('kit/record.js').makeImage(W, H, d);
}

// M Mode is always there (its first row says whether this is an M car: auto / yes / no); 2026-11-04 a client's M2 never
// saw it while it showed only once the tool had seen an M setup
// the Align page is hidden until the credit line is tapped 5 times (again: hidden); kept in the app's data folder
const UNLOCK_FILE = `${DATA}/align-unlocked`;
let alignShown = false;
try { alignShown = fs.existsSync(UNLOCK_FILE); } catch (e) { /* no data folder */ }
const UNLOCK_TAPS = 5, UNLOCK_MS = 3000;
let creditTaps = [], unlockNote = 0;
function creditTap() {
    const now = Date.now();
    creditTaps = creditTaps.filter((t) => now - t < UNLOCK_MS).concat(now);
    if (creditTaps.length < UNLOCK_TAPS) return;
    creditTaps = [];
    alignShown = !alignShown;
    try { if (alignShown) fs.writeFileSync(UNLOCK_FILE, `${new Date().toISOString()}\n`); else fs.unlinkSync(UNLOCK_FILE); } catch (e) { log('align unlock:', e.message); }
    log(`align page ${alignShown ? 'shown' : 'hidden'}`);
    unlockNote = now + 3000;
    setTimeout(render, 3050);
    if (!alignShown) { alignValues = false; if (screens.st && (screens.st.name === 'align' || screens.st.name === 'finder')) closeScreen(screens.st.name); }
    render();
}
// the 5 taps also show the Finder (step 1 of finding the car's "track my car" setting; tool 0.11.0)
const PAGES = () => (alignShown ? ['shortcuts', 'climate', 'align', 'shift', 'mmode', 'finder'] : ['shortcuts', 'climate', 'shift', 'mmode']);
const TAB_TITLES = { shortcuts: 'Shortcuts', climate: 'Climate', align: 'Align', shift: 'Shift lights', mmode: 'M Mode', finder: 'Finder' };
// the bar's buttons: row name -> the tool's key; tabs AUTO / ON / OFF
const SHOW_ROWS = { showWheel: 'driver.wheel', showDrHeat: 'driver.heat', showDrCool: 'driver.cool', showPsHeat: 'passenger.heat', showPsCool: 'passenger.cool' };
const SHOW = ['auto', 'on', 'off'], MCAR = ['auto', 'yes', 'no'];
const found = (car, key) => {                     // what the car reports for a button key
    if (!car || !car.backend) return null;
    if (key === 'driver.wheel') return !!car.wheel;
    const [seat, kind] = key.split('.');
    return !!car.seats[seat][kind];
};
// the tab a screen belongs to (the pickers open over Shortcuts)
const tabOf = (p) => (p === 'pick' || p === 'icons' ? 'shortcuts' : p);
// each screen's frame (teleShell, tabs Shortcuts | Climate | Shift lights | M Mode; the picker under Shortcuts)
const MENUS = { finder: 'finderMenu', shortcuts: 'shortcutsMenu', pick: 'pickMenu', icons: 'iconsMenu', climate: 'climateMenu', align: 'alignMenu', shift: 'shiftMenu', mmode: 'mmodeMenu' };
const CR_STATE = { connected: 'Connected', connecting: 'Starting', 'not running': 'Not running', missing: 'Not installed' };
// the M Mode page's rows A B C: SP21 cars tell M1 from M2, SP18 cars only "an M setup on"
const ROWS = () => (tool && tool.car.setups === 2
    ? [['m1', 'M1 on', 'The M Mode while M1 is active'], ['m2', 'M2 on', 'The M Mode while M2 is active'], ['off', 'M1 / M2 off', 'Back to this one']]
    : [['m1', 'M1 / M2 on', 'The M Mode while an M setup is active'], ['off', 'M1 / M2 off', 'Back to this one']]);
const STARTS = ['car', 'road', 'sport', 'track'];
const startOf = (mm) => (!mm ? 'car' : mm.start || (mm.boot ? 'sport' : 'car'));
const startSub = (mm) => ({ car: 'Leave the car\'s own mode', road: 'ROAD once the cluster is up after a start',
    sport: 'SPORT once the cluster is up after a start', track: 'TRACK once the cluster is up (the car standing still)' })[startOf(mm)];
const BACKEND = { legacy: 'Climate (G series)', master: 'Climate master', demo: 'Demo seats' };
const SIDES = ['left', 'right'];                  // where the steering wheel is (tool 0.4.0: the bar's seat buttons follow)
// the Align page (tool 0.5.0, settings.align): which button the arrows move (the picker's order, the tool's keys), the step
const ALIGN = [['all', 'All buttons'], ['driver.wheel', 'Steering wheel heating'], ['driver.heat', 'Driver seat heating'],
    ['driver.cool', 'Driver seat ventilation'], ['passenger.heat', 'Passenger seat heating'], ['passenger.cool', 'Passenger seat ventilation'],
    ['blank', 'Heat cover (passenger)']];
const ALIGN_MAX = { x: 120, ix: 40, y: 20, ly: 24, lx: 240, lhx: 120 }, STEPS = [1, 5];
// the baked-in per-button defaults (must match the tool's ALIGN_DEFAULTS): Reset restores these, not zero
const ALIGN_DEFAULTS = { 'driver.heat': { x: 36, y: -1 }, 'passenger.heat': { x: 12, y: -1, ly: 1 }, 'driver.wheel': { x: -40 } };
const alignDefault = (key) => Object.assign({ x: 0, ix: 0, y: 0, ly: 0, lx: 0, lhx: 0 }, ALIGN_DEFAULTS[key]);
// what the arrows move (tool 0.13.0): the whole button (x; up / down icon + line together), its icon alone (ix, y),
// the coloured line alone: move it as a block onto the car's line (Line: lhx, ly), or lengthen it (Reach: lx)
const MOVES = [
    { id: 'button', label: 'Button', h: 'x', v: 'both', sub: 'Button: icon, line and tap area' },
    { id: 'icon', label: 'Icon', h: 'ix', v: 'y', sub: 'Icon: the icon alone' },
    { id: 'line', label: 'Line', h: 'lhx', v: 'ly', sub: 'Line: moves the line up / down / left / right onto the car\'s line' },
    { id: 'reach', label: 'Reach', h: 'lx', v: '', sub: 'Reach: left / right makes the line longer / shorter into the car\'s line' },
];
let alignMove = 0, alignValues = false;
// three arrow pads: the heated seat (driver / passenger), the steering wheel, the rest (all / ventilation)
const PADS = { seat: ['driver.heat', 'passenger.heat', 'blank'], wheel: ['driver.wheel'], other: ['all', 'driver.cool', 'passenger.cool'] };
const padSel = { seat: 0, wheel: 0, other: 0 };
let alignStep = 0;
const padKey = (pad) => PADS[pad][padSel[pad]] || PADS[pad][0];
const alignGet = (key) => { const a = tool && tool.settings.align && tool.settings.align[key]; return { x: (a && a.x) | 0, ix: (a && a.ix) | 0, y: (a && a.y) | 0, ly: (a && a.ly) | 0, lx: (a && a.lx) | 0, lhx: (a && a.lhx) | 0 }; };
/* "Button 4 px right · icon 3 px up · line 5 px down · 80 px longer left" */
function alignText(v) {
    const lr = (n) => `${Math.abs(n)} px ${n > 0 ? 'right' : 'left'}`, ud = (n) => `${Math.abs(n)} px ${n > 0 ? 'down' : 'up'}`;
    const icon = [v.ix ? lr(v.ix) : '', v.y ? ud(v.y) : ''].filter(Boolean).join(', ');
    const line = [v.lhx ? lr(v.lhx) : '', v.ly ? ud(v.ly) : ''].filter(Boolean).join(', ');
    const p = [v.x ? `Button ${lr(v.x)}` : '', icon ? `icon ${icon}` : '', line ? `line ${line}` : '',
        v.lx ? `${Math.abs(v.lx)} px longer ${v.lx < 0 ? 'left' : 'right'}` : ''].filter(Boolean);
    return p.length ? p.join(' · ').replace(/^icon/, 'Icon').replace(/^line/, 'Line') : 'Centred';
}
const c1 = (n, axis) => Math.max(-ALIGN_MAX[axis], Math.min(ALIGN_MAX[axis], n));
function nudge(pad, dx, dy) {
    if (!tool || !tool.settings.align) return;
    const key = padKey(pad), v = alignGet(key), st = STEPS[alignStep], m = MOVES[alignMove], out = {};
    if (dx && m.h) out[m.h] = c1(v[m.h] + dx * st, m.h);
    if (dy && m.v) {
        if (m.v === 'both') { out.y = c1(v.y + dy * st, 'y'); out.ly = c1(v.ly + dy * st, 'ly'); }
        else out[m.v] = c1(v[m.v] + dy * st, m.v);
    }
    if (Object.keys(out).length) setting({ align: { [key]: out } });
}
const ARROWS = { Up: [0, -1], Down: [0, 1], Left: [-1, 0], Right: [1, 0] };
// the Values readout: every button's stored offset, raw and signed, so a photo captures the lot for the defaults
const VAL_KEYS = [['all', 'All buttons'], ['driver.heat', 'Driver seat heat'], ['passenger.heat', 'Passenger seat heat'],
    ['driver.cool', 'Driver seat vent'], ['passenger.cool', 'Passenger seat vent'], ['driver.wheel', 'Steering wheel']];
const PAD_COMPS = ['seatTitle', 'seatNow', 'seatUp', 'seatDown', 'seatLeft', 'seatRight', 'seatReset', 'seatWhich',
    'wheelTitle', 'wheelNow', 'wheelUp', 'wheelDown', 'wheelLeft', 'wheelRight', 'wheelReset',
    'otherTitle', 'otherNow', 'otherUp', 'otherDown', 'otherLeft', 'otherRight', 'otherReset', 'otherWhich'];
const pad2 = (s, n) => (s.length >= n ? s : s + ' '.repeat(n - s.length));
const valRow = (label, v) => `${label}:   x ${v.x}    ix ${v.ix}    y ${v.y}    lineY ${v.ly}    lineX ${v.lhx}    len ${v.lx}`;
const SLOTS = 7;
// the tiles are laid out left to right as they sit in the climate bar: the far-left (M) zone first, then the grid
// shortcuts in their bar order. ORDER[display position] -> the slot's own index (used for data, taps and the Slot label)
const ORDER = [5, 0, 1, 2, 3, 4, 6];
const slotSub = (i) => `Slot ${i + 1} · ${i === 5 ? 'far left (M zone)' : i === 6 ? 'freed heat spot' : i < 2 ? 'left' : i < 4 ? 'right' : 'far right'}`;
// the tool names BMW screens by the HMI's icons; the screens draw vector icons only (renderer kit/vicons.js)
const VICON = { Playlist: 'play', Navigation: 'route', Smartphone: 'phone', Menu: 'grid', MainMenu: 'display', Fan: 'fan', AndroidAuto: 'androidAuto' };
const vicon = (hmi) => VICON[hmi] || 'display';

function render() {
    if (!screens) return;
    const t = tool, pages = PAGES();
    const tabs = pages.map((p) => TAB_TITLES[p]).join(', ');
    Object.keys(MENUS).forEach((p) => screens.set(MENUS[p], { tabs, sel: Math.max(0, pages.indexOf(tabOf(p))) }));
    // shortcuts
    // the tool not running, or a shortcut whose BMW screen did not open on this car: a chip in the frame, what to do in
    // the page line (the tool learns the screen from a hold)
    const nt = t && t.notice;
    screens.set('shortcutsMenu', !t ? { chips: [['Overlays tool not running', 'crit']], sub: 'Install it from the Store, then restart the head unit' }
        : nt && nt.learn ? { chips: [[`Teach ${nt.title}`, 'warn']], sub: `Open ${nt.title}, then hold shortcut ${nt.slot + 1} in the bar for 1 s: after that it opens it` }
        : nt ? { chips: [[`${nt.title} did not open`, 'warn']], sub: `Open it yourself, then hold shortcut ${nt.slot + 1} in the bar for 1 s` }
            : { chips: [], sub: 'In the climate bar · tap one to change it' });
    const heatLeft = !!(t && t.settings.heatLeft);
    for (let p = 0; p < SLOTS; p++) {
        const i = ORDER[p];                           // tile at display position p shows the bar's slot i
        const hide = i === 6 && !heatLeft;            // the freed heat spot exists only with "passenger heat on the left" on
        // its own icon (picked) first, else an app's picture, else the BMW screen's vector icon
        const d = t && t.slots[i], own = d && d.own && icons && icons.some((x) => x.name === d.own), pic = d && d.kind === 'app' && pics[d.app];
        screens.set(`slot${p}`, { title: d ? d.title : '--', sub: d && d.missing ? 'App not installed' : slotSub(i),
            icon: own || pic ? '' : d && d.kind === 'bmw' ? vicon(d.icon) : 'display', selected: i === sel, hidden: hide });
        screens.set(`slotPic${p}`, { src: own ? `key:i:${d.own}` : `key:p:${d && d.app}`, hidden: hide || (!own && !pic) });
    }
    const cur = t && t.slots[sel];
    screens.set('showShortcuts', { on: !t || t.settings.shortcuts })
        .set('slotNow', { label: `Slot ${sel + 1}`, sub: cur ? `${cur.title} · ${cur.kind === 'app' ? 'App' : 'BMW screen'}` : '--' })
        .set('pickMenu', { title: `Slot ${sel + 1}` })
        .set('iconNow', { sub: !t ? '--' : !icons ? 'Update the Overlays tool to 0.6.0 for icons'
            : cur && cur.own === 'android-auto-color' ? aaLine(t.aa)
                : cur && cur.own ? `${iconTitle(cur.own)} · instead of the screen's own picture` : 'Default: the screen\'s own picture',
            disabled: !t || !icons, text: cur && cur.own ? iconTitle(cur.own) : 'Default' })
        .set('iconsMenu', { title: `Slot ${sel + 1} icon`, sub: cur ? `For ${cur.title} · it stays when the slot changes` : 'Shown in the climate bar' });
    // icons: Default first, then the tool's set (40 tiles)
    for (let n = 0; n < 40; n++) {
        const ic = n ? (icons || [])[n - 1] : null;
        screens.set(`ic${n}`, n === 0 ? { selected: !(cur && cur.own) }
            : ic ? { title: ic.title, pic: `key:i:${ic.name}`, letter: ic.title.charAt(0), hidden: false, selected: !!cur && cur.own === ic.name } : { hidden: true });
    }
    // pick
    const bmw = (targets && targets.bmw) || [], apps = ((targets && targets.apps) || []).slice(0, 12);
    for (let i = 0; i < 7; i++) {
        const b = bmw[i];
        screens.set(`bmw${i}`, b ? { title: b.title, sub: b.title === 'Android Auto' ? 'From your phone' : 'BMW screen', icon: vicon(b.icon), hidden: false, selected: !!cur && cur.kind === 'bmw' && cur.title === b.title } : { hidden: true });
    }
    screens.set('appsTitle', { text: targets ? (apps.length ? 'APPS ON THIS CAR' : 'APPS ON THIS CAR  ·  NONE WITH A TILE') : 'APPS ON THIS CAR  ·  READING...' });
    for (let i = 0; i < 12; i++) {
        const a = apps[i];
        // its own picture once uploaded (pictures(): 'p:<id>'), its first letter until then
        screens.set(`app${i}`, a ? { title: a.title, pic: `key:p:${a.id}`, letter: String(a.title || '?').charAt(0).toUpperCase(), hidden: false,
            selected: !!cur && cur.app === a.id } : { hidden: true });
    }
    // climate
    const car = t ? t.car : null;
    screens.set('ambientRow', { on: !t || t.settings.ambient !== false })
        .set('ambHeatRow', { hidden: !!t && t.settings.ambient === false, value: (t && t.settings.ambientHeat) || 3 })
        .set('ambCoolRow', { hidden: !!t && t.settings.ambient === false, value: (t && t.settings.ambientCool) || 9 })
        .set('orderRow', { text: t && t.settings.order === 'down' ? '3 → 2 → 1 → off' : '1 → 2 → 3 → off' })
        .set('sideRowTabs', { sel: t && t.settings.side === 'right' ? 1 : 0 })
        .set('sideRow', { sub: t && t.settings.side === 'right' ? 'The driver\'s buttons on the right, the wheel at the far right' : 'Right: the driver\'s buttons on the right' })
        .set('heatLeftRow', { on: !!(t && t.settings.heatLeft) })
        .set('blankTopRow', { on: !!(t && t.settings.blankTop), hidden: !(t && t.settings.heatLeft) })
        // the climate control found (none: the bar's AUTO buttons stay hidden, the tool shows one on AUTO only when the car has it)
        .set('climateMenu', { sub: !car ? 'Seat and steering wheel controls in the climate bar'
            : BACKEND[car.backend] ? `Seat and steering wheel controls in the climate bar · ${BACKEND[car.backend]} found`
                : 'Climate control not found yet · set a button ON to show it' });
    Object.keys(SHOW_ROWS).forEach((name) => {
        const key = SHOW_ROWS[name], f = found(car, key), v = (t && t.settings.show && t.settings.show[key]) || 'auto';
        // ON / OFF by hand: what the car reports matters less, its line fainter
        screens.set(name, { sub: f === null ? 'Auto: the car has not said yet' : `Auto: ${f ? 'found' : 'not found'} on this car`,
            subColor: v === 'auto' ? '' : 'faint' });
        screens.set(`${name}Tabs`, { sel: Math.max(0, SHOW.indexOf(v)) });
    });
    // align: an arrow pad each for the heated seat, the steering wheel and the rest; an older tool has no align (a chip, the pads off)
    const hasAlign = !!(t && t.settings.align);
    screens.set('alignMenu', { chips: !t ? [['Overlays tool not running', 'crit']] : !hasAlign ? [['Update the Overlays tool to 0.5.0', 'warn']] : [],
        sub: 'Watch the climate bar below while you tap' })
        .set('stepTabs', { sel: alignStep, disabled: !hasAlign }).set('alResetAll', { disabled: !hasAlign })
        .set('moveTabs', { sel: alignMove, disabled: !hasAlign })
        .set('moveRow', { sub: MOVES[alignMove].sub })
        // our seat / wheel buttons hidden 20 s so the car's own show (tool 0.7.0 reports peek)
        .set('peekBtn', { text: t && t.peek ? 'Show ours' : "Show BMW's own", kind: t && t.peek ? 'primary' : 'outline', disabled: !t || t.peek === undefined });
    const vals = hasAlign && alignValues;
    Object.keys(PADS).forEach((pad) => {
        if (PADS[pad].length > 1) screens.set(`${pad}Which`, { sel: padSel[pad], disabled: !hasAlign });
        screens.set(`${pad}Now`, { text: hasAlign ? alignText(alignGet(padKey(pad))) : '--' });
        ['Up', 'Down', 'Left', 'Right', 'Reset'].forEach((d) => screens.set(`${pad}${d}`, { disabled: !hasAlign }));
    });
    PAD_COMPS.forEach((n) => screens.set(n, { hidden: vals }));
    screens.set('valuesBtn', { disabled: !hasAlign, kind: vals ? 'primary' : 'outline', text: vals ? 'Hide values' : 'Values' });
    screens.set('valTitle', { hidden: !vals, text: 'ALL OFFSETS  ·  x / ix = right (+), y / line = down (+), len = line longer right (+) / left (-)  ·  take a photo' });
    VAL_KEYS.forEach(([key, label], i) => screens.set(`valLine${i}`, { hidden: !vals, text: vals ? valRow(label, alignGet(key)) : '' }));
    // shift lights
    const sh = t && t.settings.shift, ss = t && t.shift;
    if (sh) {
        screens.set('shiftRow', { on: sh.on }).set('autoRow', { on: sh.auto })
            .set('autoNow', { hidden: !sh.auto, text: ss ? `${ss.th.start} → ${ss.th.flash} rpm` : '--',
                sub: ss && ss.limit ? 'Start, then all flash at' : 'Start, then all flash at (no limit from the engine yet: the set values)' })
            .set('startRow', { hidden: sh.auto, value: sh.start }).set('flashRow', { hidden: sh.auto, value: sh.flash })
            .set('hudRow', { on: sh.hud, hidden: !sh.auto || t.car.mcar }).set('hudRow2', { on: sh.hud, hidden: sh.auto || t.car.mcar });
    }
    // the cluster renderer: green when it draws them, red when it is missing / not running / refuses (missing: a chip in
    // the frame and where to get it, the preview marked not shown)
    const refused = !!ss && !!ss.layer && /refused|error/.test(ss.layer), missing = !!ss && ss.renderer === 'missing';
    screens.set('srcRow', { text: ss && ss.own ? 'Not shown: M car' : ss && ss.dme ? 'The DME (M car)' : 'Engine speed' })
        .set('limitRow', { text: ss && ss.limit ? `${ss.limit} rpm` : 'Not reported' })
        .set('crRow', { text: ss ? (refused ? `Refused: ${ss.layer.replace(/^refused: /, '')}`.slice(0, 40) : CR_STATE[ss.renderer] || ss.renderer) : '--',
            textColor: !ss || ss.renderer === 'connecting' ? '' : ss.renderer === 'connected' && !refused ? 'ok' : 'crit',
            sub: missing ? 'Install robertnisipeanu/idrive-apps 0.3.6 or newer' : 'robertnisipeanu/idrive-apps, 0.3.6 or newer', subColor: missing ? 'warn' : '' })
        .set('noPreview', { hidden: !missing })
        .set('shiftMenu', { chips: missing ? [['Cluster renderer missing', 'crit']] : [] });
    // M Mode
    const rows = ROWS(), mm = t ? t.settings.mmode : null, isM = !!(t && t.car.mcar);
    screens.set('mcarRow', { sub: !t ? '--' : t.car.mfound ? 'Auto: found on this car' : 'Auto: not seen yet',
        subColor: mm && mm.car && mm.car !== 'auto' ? 'faint' : '' })     // YES / NO by hand: fainter, as Climate's rows
        .set('mcarTabs', { sel: Math.max(0, MCAR.indexOf((mm && mm.car) || 'auto')) })
        .set('linkRow', { on: !mm || mm.on, hidden: !isM })
        // the M Mode a start switches to (tool 0.8.0: mmode.start; an older tool: its on / off boot, shown as Sport / car's own)
        .set('bootRow', { hidden: !isM, sub: startSub(mm) })
        .set('bootTabs', { hidden: !isM, sel: Math.max(0, STARTS.indexOf(startOf(mm))) })
        .set('mmNote', { hidden: !isM }).set('mmHint', { hidden: isM });
    ['A', 'B', 'C'].forEach((k, i) => {
        const r = isM && rows[i];
        screens.set(`row${k}`, r ? { label: r[1], sub: r[2], hidden: false } : { hidden: true });
        screens.set(`tabs${k}`, r ? { sel: Math.max(0, MODES.indexOf(mm ? mm[r[0]] : 'sport')), hidden: false } : { hidden: true });
    });
    // finder
    const fl = (finder && finder.lines) || [], pagesN = Math.max(1, Math.ceil(fl.length / FINDER_ROWS));
    finderPage = Math.min(finderPage, pagesN - 1);
    const rc = finder && finder.recording, busy = !!(finder && (finder.scanning || rc));
    screens.set('finderStatus', { text: !t ? 'The Overlays tool is not running'
        : !finder ? 'Record: the files that change while you switch Track my BMW off and on. Scan: search the config files.'
            : rc === 'quiet' ? 'Recording: don\'t touch anything for 10 s...'
                : rc === 'flip' ? 'Now switch Track my BMW OFF, then ON again, then tap Stop'
                    : rc === 'listing' ? 'Listing the files that changed... (up to a minute)'
                        : finder.scanning ? 'Scanning... (up to a minute)' : finder.error ? `Could not finish: ${finder.error}`
                            : finder.total === undefined ? 'No answer: update the Overlays tool'
                                : `${finder.total} ${finder.kind === 'record' ? 'files changed while you switched it' : 'matches'} · page ${finderPage + 1} of ${pagesN}${finder.total > fl.length ? ` (first ${fl.length} shown)` : ''}` })
        .set('finderScan', { disabled: !t || busy })
        .set('finderRecord', { disabled: !t || busy })
        .set('finderStop', { disabled: rc !== 'flip', kind: rc === 'flip' ? 'primary' : 'outline' })
        .set('finderPrev', { disabled: finderPage <= 0 }).set('finderNext', { disabled: finderPage >= pagesN - 1 });
    for (let i = 0; i < FINDER_ROWS; i++) screens.set(`finderLine${i}`, { text: fl[finderPage * FINDER_ROWS + i] || '' });
    unlockChip();
}

// the unlock's note: a chip on every frame for 3 s (after render() set the pages' own)
function unlockChip() {
    if (Date.now() > unlockNote) return;
    Object.keys(MENUS).forEach((p) => screens.set(MENUS[p], { chips: [[alignShown ? 'Align page shown' : 'Align page hidden', 'ok']] }));
}

// ---- what the user does ---------------------------------------------------------------------------------
function pick(target) {
    send({ op: 'slot', i: sel, target });
    closeScreen('pick');
}
const EVENTS = {
    change: () => showScreen('pick'),                // (its 'show' asks the tool for what a slot can open)
    changeIcon: () => icons && showScreen('icons'),
    reset: () => send({ op: 'reset' }),
    credit: () => creditTap(),
    finderScan: () => {
        finder = { scanning: true, since: Date.now() }; send({ op: 'scan' }); render();
        setTimeout(() => { if (finder && finder.scanning) { finder = { error: 'no answer from the tool (update it to 0.11.0)' }; render(); } }, 75000);
    },
    finderRecord: () => {
        finder = { recording: 'quiet' }; send({ op: 'record', phase: 'start' }); render();
        setTimeout(() => { if (finder && finder.recording === 'quiet') { finder = { error: 'no answer from the tool (update it to 0.12.0)' }; render(); } }, 30000);
    },
    finderStop: () => { if (finder && finder.recording === 'flip') { send({ op: 'record', phase: 'stop' }); finder = { recording: 'listing' }; render(); } },
    finderPrev: () => { finderPage = Math.max(0, finderPage - 1); render(); },
    finderNext: () => { finderPage += 1; render(); },
    order: () => tool && setting({ order: tool.settings.order === 'down' ? 'up' : 'down' }),
    peek: () => tool && tool.peek !== undefined && send({ op: 'peek', on: !tool.peek }),
    alignValues: () => { if (tool && tool.settings.align) { alignValues = !alignValues; render(); } },
    alignResetAll: () => tool && tool.settings.align && setting({ align: ALIGN.reduce((o, [k]) => { o[k] = alignDefault(k); return o; }, {}) }),
};
function onEvent(name) {
    let m;
    if ((m = /^slot(\d)$/.exec(name)) && +m[1] < SLOTS) { sel = ORDER[+m[1]]; render(); return; }
    if ((m = /^(seat|wheel|other)(Up|Down|Left|Right|Reset)$/.exec(name))) {
        if (m[2] === 'Reset') { if (tool && tool.settings.align) setting({ align: { [padKey(m[1])]: alignDefault(padKey(m[1])) } }); } else nudge(m[1], ARROWS[m[2]][0], ARROWS[m[2]][1]);
        return;
    }
    if ((m = /^ic(\d+)$/.exec(name))) {
        const n = +m[1], ic = n ? icons && icons[n - 1] : null;
        if (n && !ic) return;
        send({ op: 'icon', i: sel, icon: ic ? ic.name : null });
        closeScreen('icons');
        return;
    }
    if ((m = /^bmw(\d)$/.exec(name))) { const b = targets && targets.bmw[+m[1]]; if (b) pick({ state: b.state, applet: b.applet }); return; }
    if ((m = /^app(\d+)$/.exec(name))) { const a = targets && targets.apps[+m[1]]; if (a) pick({ app: a.id, state: a.state, offset: a.offset }); return; }
    if (EVENTS[name]) EVENTS[name]();
}
const TOGGLES = { showShortcuts: 'shortcuts', ambientRow: 'ambient', heatLeftRow: 'heatLeft', blankTopRow: 'blankTop' };
function onChange(name, o) {
    let sr2;
    if (TOGGLES[name]) return setting({ [TOGGLES[name]]: !!o.on });
    const sr = /^(show\w+)Tabs$/.exec(name);
    if (sr && SHOW_ROWS[sr[1]] && SHOW[o.sel]) return setting({ show: { [SHOW_ROWS[sr[1]]]: SHOW[o.sel] } });
    if (name === 'mcarTabs' && MCAR[o.sel]) return setting({ mmode: { car: MCAR[o.sel] } });
    if (name === 'sideRowTabs' && SIDES[o.sel]) return setting({ side: SIDES[o.sel] });
    if ((sr2 = /^(seat|other)Which$/.exec(name)) && PADS[sr2[1]][o.sel]) { padSel[sr2[1]] = o.sel; return render(); }
    if (name === 'stepTabs' && STEPS[o.sel]) { alignStep = o.sel; return render(); }
    if (name === 'moveTabs' && MOVES[o.sel]) { alignMove = o.sel; return render(); }
    if (name === 'linkRow') return setting({ mmode: { on: !!o.on } });
    // a tool before 0.8.0 knows only boot (on: SPORT): sent too, so Car's own / Sport work there
    if (name === 'bootTabs' && STARTS[o.sel]) return setting({ mmode: { start: STARTS[o.sel], boot: STARTS[o.sel] !== 'car' } });
    if (name === 'shiftRow') return setting({ shift: { on: !!o.on } });
    if (name === 'autoRow') return setting({ shift: { auto: !!o.on } });
    if (name === 'hudRow' || name === 'hudRow2') return setting({ shift: { hud: !!o.on } });
    if (name === 'ambHeatRow' || name === 'ambCoolRow') return setting({ [name === 'ambHeatRow' ? 'ambientHeat' : 'ambientCool']: Math.round(o.value) });
    if (name === 'startRow' || name === 'flashRow') return setting({ shift: { [name === 'startRow' ? 'start' : 'flash']: Math.round(o.value / 100) * 100 } });
    const t = /^tabs([ABC])$/.exec(name), r = t && ROWS()['ABC'.indexOf(t[1])];
    if (r) return setting({ mmode: { [r[0]]: MODES[o.sel] } });
    const page = Object.keys(MENUS).find((p) => MENUS[p] === name);
    if (page) {                                       // a tab (o is the shell's opts: read before the set)
        const to = PAGES()[o.sel];
        screens.set(name, { sel: Math.max(0, PAGES().indexOf(tabOf(page))) });
        goTo(to);
    }
    return null;
}
// shortcuts is the app's first screen, the other pages open over it (BACK returns to it)
function goTo(page) {
    const cur = screens.st && screens.st.name;
    if (!page || page === cur) return;
    if (cur && cur !== 'shortcuts') closeScreen(cur);
    if (page !== 'shortcuts') showScreen(page);
}

// ---- RHMI: the host states (the shared OnlineApp host hands over the RHMI application) -------------------
let app = null;
const comp = (n) => app.getByName(n);
function showScreen(name) {
    return comp(name).updateResources().then(() => app.openState(name))
        .then(() => log(`opened ${name}`))
        .catch((e) => log(`open ${name} failed:`, e));
}
const closeScreen = (name) => app.closeState(name).catch((e) => log(`close ${name} failed:`, e));

function startScreens(rhmiApp) {
    app = rhmiApp;
    const design = JSON.parse(fs.readFileSync(path.join(RENDERER, 'screens.json'), 'utf8'));
    const { RenderClient } = runtime('kit/renderd.js');
    const { ScreenApp } = runtime('screenapp.js');
    const rlog = { info: (m) => log(m), warn: (m) => log(m), error: (m) => log(m) };
    const gpu = new RenderClient('carlm_overlays', rlog);
    screens = new ScreenApp(gpu, design, { view: 'id8', log: rlog });
    try { screens.setImage('shiftPreview', barsPicture()); } catch (e) { log('shift preview:', e.message); }
    const hosts = {};
    STATES.forEach((s) => { hosts[s] = comp(s); });
    screens.bindHosts(hosts, { open: (name) => showScreen(name), close: closeScreen });
    screens.on('event', (n) => { try { onEvent(n); } catch (e) { log(`${n} failed:`, e); } });
    screens.on('change', (n, o) => { try { onChange(n, o); } catch (e) { log(`${n} failed:`, e); } });
    screens.on('show', (name) => { if (name === 'pick') send({ op: 'targets' }); render(); });
    // the user left for the HMI (touched it): leave the host states too, or the HMI would show its empty page
    screens.on('closed', (why) => { if (why !== 'hmi') STATES.slice().reverse().forEach(closeScreen); });
    gpu.connect();
    connect();
    render();
}

// ---- lifecycle: the shared OnlineApp host (start, tile, shutdown) -----------------------------------------
log('start', process.getuid());
createHost({
    states: STATES,
    log,
    onReady: (rhmiApp) => { startScreens(rhmiApp); log('screens ready'); },
});
